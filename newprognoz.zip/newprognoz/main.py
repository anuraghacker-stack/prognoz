import logging
import sqlite3
import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ParseMode
from aiogram.utils import executor
from pyowm import OWM

# Настройте логирование
logging.basicConfig(level=logging.INFO)

# Замените "YOUR_API_KEY" на свой API-ключ OpenWeatherMap
owm = OWM("f5958db62d55a4e34a791280511428f6")
bot = Bot(token="6518600766:AAH_tsoQljiWgoYlKGXvN9rCwG-uV4Ncjbg")
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

# Создайте или подключитесь к базе данных SQLite
conn = sqlite3.connect("users.db")
cursor = conn.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        first_name TEXT,
        username TEXT,
        registration_date DATETIME,
        status TEXT,
        city_requests INTEGER
    )
""")
conn.commit()

# Задайте заготовки для рекомендаций по одежде
outfits = {
    "hot": ["шорты и майку", "шорты и футболку", "легкую одежду и воду"],
    "cold": ["теплую куртку и шапку", "пальто и шарф", "теплую кофту и перчатки"],
    "rain": ["зонтик и водонепроницаемую одежду", "легкую куртку и сапоги"]
}


@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    username = message.from_user.username
    registration_date = message.date
    status = "admin" if user_id == 1878928932 else "user"
    city_requests = 0

    cursor.execute("INSERT OR IGNORE INTO users (id, first_name, username, registration_date, status, city_requests) VALUES (?, ?, ?, ?, ?, ?)",
                   (user_id, first_name, username, registration_date, status, city_requests))
    conn.commit()

    await message.reply("Привет! Я бот Прогноз Одежды. Введите название города, чтобы получить рекомендации по одежде.")


@dp.message_handler(Text(equals="🌦 Прогноз погоды"))
async def get_weather(message: types.Message):
    await message.reply("Введите название города для получения прогноза погоды.")


@dp.message_handler(lambda message: message.text.lower() in outfits.keys())
async def recommend_outfit(message: types.Message):
    user_id = message.from_user.id
    weather_type = message.text.lower()

    cursor.execute("SELECT city_requests FROM users WHERE id=?", (user_id,))
    city_requests = cursor.fetchone()[0] + 1

    cursor.execute("UPDATE users SET city_requests=? WHERE id=?", (city_requests, user_id))
    conn.commit()

    recommendations = outfits[weather_type]
    recommendation_text = f"Сегодня лучше надеть: {', '.join(recommendations)}."

    await message.reply(recommendation_text)


@dp.message_handler()
async def get_weather_info(message: types.Message):
    user_id = message.from_user.id
    city_name = message.text

    # Получите прогноз погоды с OpenWeatherMap
    mgr = owm.weather_manager()
    try:
        observation = mgr.weather_at_place(city_name)
        w = observation.weather
        temperature = w.temperature('celsius')['temp']
        humidity = w.humidity
        wind_speed = w.wind()['speed']

        # Определите тип погоды
        weather_type = "hot" if temperature > 25 else "cold" if temperature < 10 else "rain" if humidity > 70 else "moderate"

        cursor.execute("SELECT city_requests FROM users WHERE id=?", (user_id,))
        city_requests = cursor.fetchone()[0] + 1

        cursor.execute("UPDATE users SET city_requests=? WHERE id=?", (city_requests, user_id))
        conn.commit()

        recommendations = outfits[weather_type]
        recommendation_text = f"Сегодня лучше надеть: {', '.join(recommendations)}."

        await message.reply(f"Погода в {city_name}:\n"
                            f"Температура: {temperature}°C\n"
                            f"Влажность: {humidity}%\n"
                            f"Скорость ветра: {wind_speed} м/с\n\n"
                            f"{recommendation_text}")

    except Exception as e:
        await message.reply("Не удалось получить информацию о погоде. Пожалуйста, проверьте название города и попробуйте снова.")


if __name__ == '__main__':
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)
